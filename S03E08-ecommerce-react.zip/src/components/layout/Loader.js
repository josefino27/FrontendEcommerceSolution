import React from 'react'

const Loader = () => {
  return (
    <div className="loader" />
  )
}

export default Loader